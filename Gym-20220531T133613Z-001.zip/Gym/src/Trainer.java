import java.util.ArrayList;

public class Trainer extends Employee {
	// VARIABLES
	ArrayList<String> branches = new ArrayList<>();
	private int experience;

	// CONSTRUCTOR METHOD
	public Trainer(String id, String name, String surname, String tcNumber, String phoneNumber, String mailAdress,
			String adress, String sex, int age, String graduationStatus, double workingTime, double hourlyRate,
			int experience) {
		super(id, name, surname, tcNumber, phoneNumber, mailAdress, adress, sex, age, graduationStatus, workingTime,
				hourlyRate);
		this.experience = experience;
	}

	// GETTERS AND SETTERS

	public int getExperience() {
		return experience;
	}

	public ArrayList<String> getBranches() {
		return branches;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	@Override
	public void printInfo() {
		super.printInfo();
		System.out.println(getExperience());
		for (String branch : branches) {
			System.out.println(branch);
		}
	}

	public void addBranches(String branche) {
		branches.add(branche);
	}

}
