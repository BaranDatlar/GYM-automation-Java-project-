public class Supplement {
	//VARIABLES
	private String idSupplement;
	private String nameSUpplement;
	
	//CONSTRUCTOR METHOD
	public Supplement(String idSupplement, String nameSUpplement) {
		this.idSupplement = idSupplement;
		this.nameSUpplement = nameSUpplement;
	}
	
	//GETTERS AND SETTERS
	public String getIdSupplement() {
		return idSupplement;
	}

	public void setIdSupplement(String idSupplement) {
		this.idSupplement = idSupplement;
	}

	public String getNameSUpplement() {
		return nameSUpplement;
	}

	public void setNameSUpplement(String nameSUpplement) {
		this.nameSUpplement = nameSUpplement;
	}
	

	
}
