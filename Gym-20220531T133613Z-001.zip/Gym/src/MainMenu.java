import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class MainMenu extends JFrame {
    private JButton addTrainerButton;
    private JButton addCustomerButton;
    private JButton addMaintanceStaffButton;
    private JButton optionsButton;
    private JPanel mainMenu;

    public MainMenu(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        add(mainMenu);
        setTitle("Main Menu");
        setSize(400,400);

        addCustomerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddCustomer addCustomer = new AddCustomer();
                addCustomer.setVisible(true);
            }
        });
        addTrainerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddTrainer addTrainer = new AddTrainer();
                addTrainer.setVisible(true);
            }
        });
        addMaintanceStaffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddMaintanceStaff addMaintanceStaff = new AddMaintanceStaff();
                addMaintanceStaff.setVisible(true);
            }
        });
        optionsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                OptForm optForm = new OptForm();
                optForm.setVisible(true);

            }
        });
    }
}
