import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;


public class Main {
	public static void main(String[] args) throws SQLException {
		Trainer fightTrainer = new Trainer("1","ahmet","çakar","12312312312","5355555555","ggwp@hotmail.com","ankara","male",35,"lise",35.0,50,10);
		Fight fight = new Fight("1","Boks",150,fightTrainer,"Çarşamba Cumartesi saat 19.00");
		MainMenu menu = new MainMenu();
		menu.setVisible(true);

	}
}
