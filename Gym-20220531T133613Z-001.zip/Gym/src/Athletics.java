public class Athletics extends Course{
	
	//CONSTRUCTOR METHOD
	public Athletics(String id, String name, double monthlyRate, Trainer trainer, String timeInfo) {
		super(id, name, monthlyRate, trainer, timeInfo);
	}

	
}
