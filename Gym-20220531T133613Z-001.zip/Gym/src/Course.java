public class Course extends Plan {
	//VARIABLES
	private Trainer trainer;
	private String timeInfo;
	
	//CONSTRUCTOR METHOD
	public Course(String id, String name, double monthlyRate, Trainer trainer, String timeInfo) {
		super(id, name, monthlyRate);
		this.trainer = trainer;
		this.timeInfo = timeInfo;
	}
	
	//GETTERS AND SETTERS
	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	public String getTimeInfo() {
		return timeInfo;
	}

	public void setTimeInfo(String timeInfo) {
		this.timeInfo = timeInfo;
	}
	
	
	
}
