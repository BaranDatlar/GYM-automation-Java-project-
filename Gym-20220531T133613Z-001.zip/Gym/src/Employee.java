public class Employee extends Person {
	// VARIABLES
	private double salary;
	private String graduationStatus;
	private double workingTime;
	private double hourlyRate;

	// CONSTRUCTOR METHOD
	public Employee(String id, String name, String surname, String tcNumber, String phoneNumber, String mailAdress,
			String adress, String sex, int age, String graduationStatus, double workingTime, double hourlyRate) {
		super(id, name, surname, tcNumber, phoneNumber, mailAdress, adress, sex, age);
		this.graduationStatus = graduationStatus;
		this.workingTime = workingTime;
		this.hourlyRate = hourlyRate;
	}

	// GETTERS AND SETTERS
	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getGraduationStatus() {
		return graduationStatus;
	}

	public void setGraduationStatus(String graduationStatus) {
		this.graduationStatus = graduationStatus;
	}

	public double getWorkingTime() {
		return workingTime;
	}

	public void setWorkingTime(double workingTime) {
		this.workingTime = workingTime;
	}

	public double getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(double hourlyRate) {
		this.hourlyRate = hourlyRate;
	}

	@Override
	public void printInfo() {
		super.printInfo();
		System.out.println(getSalary() + getGraduationStatus() + getWorkingTime() + getHourlyRate());
	}

	public void calculateSalary() {

		this.salary = this.hourlyRate * this.workingTime;
	}

}
