import java.util.ArrayList;

public class Person {
	// VARIABLES
	private String id;
	private String name;
	private String surname;
	private String tcNumber;
	private String phoneNumber;
	private String mailAdress;
	private String adress;
	private String sex;
	private int age;
	ArrayList<String> diseases = new ArrayList<>();

	// CONSTRUCTOR METOD
	public Person(String id, String name, String surname, String tcNumber, String phoneNumber, String mailAdress,
			String adress, String sex, int age) {
		this.id = id;
		this.name = name;
		this.surname = surname;
		this.tcNumber = tcNumber;
		this.phoneNumber = phoneNumber;
		this.mailAdress = mailAdress;
		this.adress = adress;
		this.sex = sex;
		this.age = age;
	}

	// GETTERS AND SETTERS
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getTcNumber() {
		return tcNumber;
	}

	public void setTcNumber(String tcNumber) {
		this.tcNumber = tcNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getMailAdress() {
		return mailAdress;
	}

	public void setMailAdress(String mailAdress) {
		this.mailAdress = mailAdress;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public ArrayList<String> getDiseases() {
		return diseases;
	}

	public void addDiseases(String disease) {
		this.diseases.add(disease);
	}

	public void printInfo() {
		System.out.println(getId() + getName() + getSurname() + getTcNumber() + getPhoneNumber() + getMailAdress()
				+ getAdress() + getSex() + getAge());
		for (String disease : diseases) {
			System.out.println(disease);
		}
	}

	public boolean checkHealth() {
		if (diseases.size() > 0) {
			System.out.println("Spor yapmas� tehlikelidir.");
			return false;
		} else {
			System.out.println("Spor yapabilir.");
			return true;
		}

	}
}
