public class Move {
	
	//VARIABLES
	private String idMove;
	private String nameMove;
	
	//CONSTRUCTOR METHOD
	public Move(String idMove, String nameMove) {
		this.idMove = idMove;
		this.nameMove = nameMove;
	}

	//GETTERS AND SETTERS
	public String getIdMove() {
		return idMove;
	}

	public void setIdMove(String idMove) {
		this.idMove = idMove;
	}

	public String getNameMove() {
		return nameMove;
	}

	public void setNameMove(String nameMove) {
		this.nameMove = nameMove;
	}
	
	
	
}
