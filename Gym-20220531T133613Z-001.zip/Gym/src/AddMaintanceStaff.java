import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddMaintanceStaff extends JFrame{
    private JPanel MaintancePanel;
    private JTextField maintanceStaddId;
    private JComboBox maintanceStaffSexComb;
    private JComboBox maintanceStaffGradComb;
    private JTextField maintanceStaffName;
    private JTextField maintanceStaffSurname;
    private JTextField maintanceStaffTC;
    private JTextField maintanceStaffPhone;
    private JTextField maintanceStaffMail;
    private JTextField maintanceStaffAdress;
    private JTextField maintanceStaffAge;
    private JTextField maintanceStaffHourlyRate;
    private JTextField maintanceStaffWorktime;
    private JButton addButton;

    public AddMaintanceStaff(){
        add(MaintancePanel);
        setSize(400,600);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MaintanceStaff maintanceStaff = new MaintanceStaff(
                        maintanceStaddId.getText(),
                        maintanceStaffName.getText(),
                        maintanceStaffSurname.getText(),
                        maintanceStaffTC.getText(),
                        maintanceStaffPhone.getText(),
                        maintanceStaffMail.getText(),
                        maintanceStaffAdress.getText(),
                        maintanceStaffSexComb.getSelectedItem().toString(),
                        Integer.parseInt(maintanceStaffAge.getText()),
                        maintanceStaffGradComb.getSelectedItem().toString(),
                        Double.parseDouble(maintanceStaffWorktime.getText()),
                        Double.parseDouble(maintanceStaffHourlyRate.getText())
                );
                maintanceStaff.calculateSalary();
                try {
                    Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                    Statement st = c.createStatement();
                    String query = "INSERT INTO staff (id,name,surname,tc,phone,mail,adress,sex,age,graduation,worktime,hourlyrate,salary) VALUES ('"+maintanceStaff.getId()+"','"+maintanceStaff.getName()+"','"+maintanceStaff.getSurname()+"','"+maintanceStaff.getTcNumber()+"','"+maintanceStaff.getPhoneNumber()+"','"+maintanceStaff.getMailAdress()+"','"+maintanceStaff.getAdress()+"','"+maintanceStaff.getSex()+"','"+maintanceStaff.getAge()+"', '"+maintanceStaff.getGraduationStatus()+"', '"+maintanceStaff.getWorkingTime()+"','"+maintanceStaff.getHourlyRate()+"','"+maintanceStaff.getSalary()+"')";
                    st.executeUpdate(query);
                    st.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

            }
        });
    }
}
