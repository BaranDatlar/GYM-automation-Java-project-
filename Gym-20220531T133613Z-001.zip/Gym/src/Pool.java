public class Pool extends Course{
	
	//CONSTRUCTOR METHOD
	public Pool(String id, String name, double monthlyRate, Trainer trainer, String timeInfo) {
		super(id, name, monthlyRate, trainer, timeInfo);
	}
	
	

}
