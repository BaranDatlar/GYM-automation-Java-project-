public class Equipment {
	//VARIABLES
	private String idEquipment;
	private String nameEquipment;
	
	//CONSTRUCTOR METHOD
	public Equipment(String idEquipment, String nameEquipment) {
		this.idEquipment = idEquipment;
		this.nameEquipment = nameEquipment;
	}

	//GETTERS AND SETTERS
	public String getIdEquipment() {
		return idEquipment;
	}

	public void setIdEquipment(String idEquipment) {
		this.idEquipment = idEquipment;
	}

	public String getNameEquipment() {
		return nameEquipment;
	}

	public void setNameEquipment(String nameEquipment) {
		this.nameEquipment = nameEquipment;
	}
		
	
}
