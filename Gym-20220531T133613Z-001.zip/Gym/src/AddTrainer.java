import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddTrainer extends JFrame {
    private JTextField trainerId;
    private JTextField trainerName;
    private JTextField trainerSurname;
    private JTextField trainerTC;
    private JTextField trainerPhone;
    private JTextField trainerMail;
    private JTextField trainerAdress;
    private JTextField trainerAge;
    private JTextField trainerHourlyRate;
    private JTextField trainerWorkTime;
    private JTextField trainerExperience;
    private JComboBox trainerGraduate;
    private JComboBox trainerSex;
    private JCheckBox fitnessCheckBox;
    private JCheckBox fightCheckBox;
    private JCheckBox havuzCheckBox;
    private JCheckBox atletizmCheckBox;
    private JPanel TrainerPanel;
    private JButton ekleButton;

    public AddTrainer(){
        add(TrainerPanel);
        setTitle("Eğitmen Ekle");
        setSize(400,700);

        ekleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Trainer trainer = new Trainer(trainerId.getText(),
                        trainerName.getText(),
                        trainerSurname.getText(),
                        trainerTC.getText(),
                        trainerPhone.getText(),
                        trainerMail.getText(),
                        trainerAdress.getText(),
                        trainerSex.getSelectedItem().toString(),
                        Integer.parseInt(trainerAge.getText()),
                        trainerGraduate.getSelectedItem().toString(),
                        Double.parseDouble(trainerWorkTime.getText()),
                        Double.parseDouble(trainerHourlyRate.getText()),
                        Integer.parseInt(trainerExperience.getText())
                );
                if (atletizmCheckBox.isSelected())
                    trainer.addBranches(atletizmCheckBox.getText());
                if (fightCheckBox.isSelected())
                    trainer.addBranches(fightCheckBox.getText());
                if (havuzCheckBox.isSelected())
                    trainer.addBranches(havuzCheckBox.getText());
                if (fitnessCheckBox.isSelected())
                    trainer.addBranches(fitnessCheckBox.getText());
                String brc = "";
                for (String bran:trainer.branches){
                    brc+=bran;
                }
                trainer.calculateSalary();
                try {
                    Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                    Statement st = c.createStatement();
                    String query = "INSERT INTO trainer (id,name,surname,tc,phone,mail,adress,sex,age,graduation,worktime,hourlyrate,experience,branches,salary) VALUES ('"+trainer.getId()+"','"+trainer.getName()+"','"+trainer.getSurname()+"','"+trainer.getTcNumber()+"','"+trainer.getPhoneNumber()+"','"+trainer.getMailAdress()+"','"+trainer.getAdress()+"','"+trainer.getSex()+"','"+trainer.getAge()+"', '"+trainer.getGraduationStatus()+"', '"+trainer.getWorkingTime()+"','"+trainer.getHourlyRate()+"','"+trainer.getExperience()+"','"+brc+"','"+trainer.getSalary()+"')";
                    st.executeUpdate(query);
                    st.close();

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }
}
