public class Plan {
	//VARIABLES
	private String id;
	private String name;
	private double monthlyRate;
	
	//CONSTRUCTOR METHOD
	public Plan(String id, String name, double monthlyRate) {
		this.id = id;
		this.name = name;
		this.monthlyRate = monthlyRate;
	}

	//GETTERS AND SETTERS
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMonthlyRate() {
		return monthlyRate;
	}

	public void setMonthlyRate(double monthlyRate) {
		this.monthlyRate = monthlyRate;
	}
	
}
