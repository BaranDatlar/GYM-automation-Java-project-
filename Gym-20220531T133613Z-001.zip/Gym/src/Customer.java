import java.sql.*;
import java.util.Scanner;

public class Customer extends Person {
	//VARIABLES
	private double weight;
	private double height;
	private double bmi;
	private boolean isExperienced;
	private int month;
	private Plan plan;
	private String planName;
	private double price;
	
	//CONSTRUCTOR METOD
	public Customer(String id, String name, String surname, String tcNumber, String phoneNumber, String mailAdress,
			String adress, String sex, int age, double weight, double height,
			boolean isExperienced, int month) {
		super(id, name, surname, tcNumber, phoneNumber, mailAdress, adress, sex, age);
		this.weight = weight;
		this.height = height;
		this.isExperienced = isExperienced;
		this.month = month;
	}

	//GETTERS AND SETTERS
	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getBmi() {
		return bmi;
	}

	public boolean getIsExperienced() {
		return isExperienced;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public String getPlanName() {
		return planName;
	}

	public double getPrice() {
		return price;
	}

	@Override
	public void printInfo() {
		super.printInfo();
		System.out.println(getWeight() + getHeight() + getBmi() + String.valueOf(getIsExperienced()) + getMonth() + getPlanName() + getPrice());
	}
	public void calculateBmi() {
		 this.bmi = this.weight/(this.height*this.height);
	}

	public void calculatePrice(){
		this.price = this.month*this.plan.getMonthlyRate();
	}
	
	public void makePlan(int choice) {

		switch(choice) {
		
			case 0:
				if (this.bmi<15){
					Fitness fullBody = new Fitness("11","fullbody",200);
					this.plan = fullBody;
					this.planName = fullBody.getName();
				}
				else{
					Fitness spLit = new Fitness("12","split",150);
					this.plan = spLit;
					this.planName = spLit.getName();
				}
				break;
		
			case 1:
				Trainer fightTrainer = new Trainer("1","ahmet","çakar","12312312312","5355555555","ggwp@hotmail.com","ankara","male",35,"lise",35.0,50,10);
				Fight fight = new Fight("1","Boks",150,fightTrainer,"Çarşamba Cumartesi saat 19.00");
				this.plan = fight;

				this.planName = fight.getTrainer().getName() + fight.getTrainer().getSurname() + fight.getTimeInfo() + fight.getName();
				break;

			case 2:
				Trainer poolTrainer = new Trainer("2","veli","çakar","12312312312","5355555555","ggwp@hotmail.com","ankara","male",35,"lise",35.0,50,10);
				Pool pool = new Pool("1","Kuğu gölü balesi",200,poolTrainer,"pazar Cumartesi saat 9.00");
				this.plan = pool;

				this.planName = pool.getTrainer().getName() + pool.getTrainer().getSurname() + pool.getTimeInfo() + pool.getName();
				break;

			case 3:
				Trainer athleticTrainer = new Trainer("3","mehmet","çakar","12312312312","5355555555","ggwp@hotmail.com","ankara","male",35,"lise",35.0,50,10);
				Athletics athletics = new Athletics("1","Kuğu gölü balesi",250,athleticTrainer,"pazar Cumartesi saat 9.00");
				this.plan = athletics;

				this.planName = athletics.getTrainer().getName() + athletics.getTrainer().getSurname() + athletics.getTimeInfo() + athletics.getName();
				break;

			
		}
	}

}
