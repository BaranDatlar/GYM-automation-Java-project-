import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class AddCustomer extends JFrame {
    private JTextField customerId;
    private JTextField customerName;
    private JTextField customerSurname;
    private JTextField customerTC;
    private JTextField customerPhone;
    private JTextField customerMail;
    private JTextField customerAdress;
    private JTextField customerAge;
    private JTextField customerHeight;
    private JTextField customerWeight;
    private JTextField customerMonth;
    private JComboBox sexComboBox;
    private JComboBox customerIsExperienced;
    private JPanel customerPanel;
    private JButton addButton;
    private JCheckBox kalpDamarCheckBox;
    private JCheckBox kalpKoronerCheckBox;
    private JCheckBox hipertansiyonCheckBox;
    private JTextField textField1;
    private JCheckBox hipotansiyonCheckBox;
    private JComboBox comboBox1;

    public AddCustomer(){
        add(customerPanel);
        setSize(400,700);
        setTitle("Müşteri Ekle");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                boolean isExperienced;
                if (customerIsExperienced.toString().equals("Evet")){
                    isExperienced = true;
                }
                else{
                    isExperienced = false;
                }
                Customer customer = new Customer(
                        customerId.getText(),
                        customerName.getText(),
                        customerSurname.getText(),
                        customerTC.getText(),
                        customerPhone.getText(),
                        customerMail.getText(),
                        customerAdress.getText(),
                        sexComboBox.getSelectedItem().toString(),
                        Integer.parseInt(customerAge.getText()),
                        Double.parseDouble(customerWeight.getText()),
                        Double.parseDouble(customerHeight.getText()),
                        isExperienced,
                        Integer.parseInt(customerMonth.getText())
                );

                if (kalpDamarCheckBox.isSelected())
                    customer.addDiseases(kalpDamarCheckBox.getText());
                if (kalpKoronerCheckBox.isSelected())
                    customer.addDiseases(kalpKoronerCheckBox.getText());
                if (hipertansiyonCheckBox.isSelected())
                    customer.addDiseases(hipertansiyonCheckBox.getText());
                if (hipotansiyonCheckBox.isSelected())
                    customer.addDiseases(hipotansiyonCheckBox.getText());

                if (kalpDamarCheckBox.isSelected() || kalpKoronerCheckBox.isSelected() || hipertansiyonCheckBox.isSelected() || hipotansiyonCheckBox.isSelected()){
                    Object[] options = {"Yes","No"};

                    int n = JOptionPane.YES_NO_OPTION;
                    JOptionPane.showConfirmDialog(null,"Spor yapmanız sakıncalıdır. Yine de devam etmek ister misiniz ?","Dikkat",n);
                    if (n==JOptionPane.YES_OPTION){
                        customer.addDiseases(textField1.getText());
                        customer.makePlan(comboBox1.getSelectedIndex());
                        customer.calculateBmi();
                        customer.calculatePrice();

                        String diseases = "";
                        for (String disease : customer.diseases){
                            diseases += disease;
                        }

                        try {
                            Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                            Statement st = c.createStatement();
                            String query = "INSERT INTO customer (id,name,surname,tc,phone,mail,adress,sex,age,weight,height,experienced,month,diseases,plan,bmi,price) " +
                                    "VALUES ('"+customer.getId()+"','"+customer.getName()+"','"+customer.getSurname()+"','"+customer.getTcNumber()+"','"+customer.getPhoneNumber()+"'," +
                                    "'"+customer.getMailAdress()+"','"+customer.getAdress()+"','"+customer.getSex()+"','"+customer.getAge()+"','"+customer.getWeight()+"','"+customer.getHeight()+"'," +
                                    "'"+customer.getIsExperienced()+"','"+customer.getMonth()+"','"+diseases+"','asd','"+customer.getBmi()+"','"+customer.getPrice()+"')";
                            st.executeUpdate(query);
                            st.close();

                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (n==JOptionPane.NO_OPTION){
                        remove(n);
                    }

                }
                else{
                    customer.addDiseases(textField1.getText());
                    customer.makePlan(comboBox1.getSelectedIndex());
                    customer.calculateBmi();
                    customer.calculatePrice();

                    String diseases = "";
                    for (String disease : customer.diseases){
                        diseases += disease;
                    }

                    try {
                        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                        Statement st = c.createStatement();
                        String query = "INSERT INTO customer (id,name,surname,tc,phone,mail,adress,sex,age,weight,height,experienced,month,diseases,plan,bmi,price) " +
                                "VALUES ('"+customer.getId()+"','"+customer.getName()+"','"+customer.getSurname()+"','"+customer.getTcNumber()+"','"+customer.getPhoneNumber()+"'," +
                                "'"+customer.getMailAdress()+"','"+customer.getAdress()+"','"+customer.getSex()+"','"+customer.getAge()+"','"+customer.getWeight()+"','"+customer.getHeight()+"'," +
                                "'"+customer.getIsExperienced()+"','"+customer.getMonth()+"','"+diseases+"','asd','"+customer.getBmi()+"','"+customer.getPrice()+"')";
                        st.executeUpdate(query);
                        st.close();

                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }

                JOptionPane.showMessageDialog(null,customer.getPlanName());




            }
        });
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
