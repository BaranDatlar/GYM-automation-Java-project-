
public class Test {

	public static void main(String[] args) {
		Person baran = new Person("191180031","baran","datlar","45371008996","5436427735","barandatlarr@gmail.com","karab�k","man",21);
		baran.printInfo();
	}

}
