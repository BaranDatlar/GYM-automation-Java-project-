public class Fight extends Course {
	
	//CONSTRUCTOR METHOD	
	public Fight(String id, String name, double monthlyRate, Trainer trainer, String timeInfo) {
		super(id, name, monthlyRate, trainer, timeInfo);
	}
	
	
}
