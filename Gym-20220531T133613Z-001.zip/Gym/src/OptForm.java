

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class OptForm extends JFrame {
    private JPanel OptPanel;
    private JTextField eqId;
    private JTextField supId;
    private JTextField supName;
    private JTextField eqName;
    private JButton ekleButton;
    private JButton ekleButton1;
    private JTextField moveId;
    private JTextField moveName;
    private JButton ekleButton2;

    public OptForm() {

        add(OptPanel);
        setSize(600,400);
        setTitle("Options");
        ekleButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Equipment equipment = new Equipment(eqId.getText(),eqName.getText());
                try {
                    Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                    Statement st = c.createStatement();
                    String query = "INSERT INTO equipment (id,name) VALUES ('"+equipment.getIdEquipment()+"' , '"+equipment.getNameEquipment()+"')";
                    st.executeUpdate(query);
                    st.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }


            }
        });
        ekleButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Supplement supplement = new Supplement(supId.getText(),supName.getText());
                try {
                    Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                    Statement st = c.createStatement();
                    String query = "INSERT INTO supplement (id,name) VALUES ('"+supplement.getIdSupplement()+"' , '"+supplement.getNameSUpplement()+"')";
                    st.executeUpdate(query);
                    st.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        ekleButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Move move = new Move(moveId.getText(),moveName.getText());
                try {
                    Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3306/gym?user=root&password=1234");
                    Statement st = c.createStatement();
                    String query = "INSERT INTO move  (id,name) VALUES ('"+move.getIdMove()+"' , '"+move.getNameMove()+"')";
                    st.executeUpdate(query);
                    st.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
    }

}
