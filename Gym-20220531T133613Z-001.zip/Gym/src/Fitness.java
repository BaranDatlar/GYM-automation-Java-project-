public class Fitness extends Plan {

	//CONSTRUCTOR METHOD
	public Fitness(String id, String name, double monthlyRate) {
		super(id, name, monthlyRate);
	}
	
	
}
